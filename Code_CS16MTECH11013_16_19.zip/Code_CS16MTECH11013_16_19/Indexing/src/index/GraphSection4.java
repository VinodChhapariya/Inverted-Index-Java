package index;
import java.awt.BorderLayout;
import java.awt.Container;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
@SuppressWarnings("serial")
public class GraphSection4 extends ApplicationFrame{
	public static HashMap<String, LinkedHashMap<String,Integer>>invertedIndex4 = new HashMap<String,LinkedHashMap<String,Integer>>();
	public int docCount=0;
	public ArrayList<String> terms = new ArrayList<String>();
	public GraphSection4(String title) throws IOException {
		super(title);
		IndexMain index=new IndexMain();
		//invoking methods in IndexMain class to get the inverted index 4 and the number of documents*/
		invertedIndex4=index.getIndex4();
		docCount=index.getDocCount();
		final XYSeries series = new XYSeries("Data");
		int term_M=0;
		int token_T=0;
		/*calculating the #terms and #tokens in each document cumulatively*/
		for(int i=1;i<=docCount;i++){
			String id="DOCID:"+i;
			LinkedHashMap<Integer, Integer> token_term=new LinkedHashMap<Integer, Integer>();
			for (String key : invertedIndex4.keySet()) {
				LinkedHashMap<String,Integer> postings=new LinkedHashMap<String,Integer>();
				postings=invertedIndex4.get(key);
				if(postings.containsKey(id)){
					if(!(terms.contains(key))){
						terms.add(key);
						term_M+=1;
					}
					token_T+=postings.get(id);
				}
			}
			/*adding the log(#tokens) and log(#terms) as x and y axis values respectively*/
			series.add(Math.log10(token_T),Math.log10(term_M));
		}
		/*plotting graph*/
		final XYSeriesCollection data = new XYSeriesCollection(series);
	    final JFreeChart chart = ChartFactory.createXYLineChart("Token count Vs Vocabulary size ","log(#tokens)","log(#terms)",data,PlotOrientation.VERTICAL,true,true,false);
	    final ChartPanel chartPanel = new ChartPanel(chart);
	    chartPanel.setPreferredSize(new java.awt.Dimension(900, 500));
	    JFrame frame = new JFrame("#Tokens - #Terms Plot");
	    Container pane = frame.getContentPane();
	    pane.setLayout(new BorderLayout()); 
	    pane.add(chartPanel);
	    frame.pack();
	    frame.setLocation(1000,400);
	    frame.setVisible(true);
	    ChartUtilities.saveChartAsJPEG(new File("tokenCount_termCount_graph.jpg"), chart, 900, 500);
	}
}
