
package index;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jfree.ui.RefineryUtilities;
import org.tartarus.snowball.EnglishSnowballStemmerFactory;
import org.tartarus.snowball.util.StemmerException;

public class IndexMain {
	/*docCount stores the total number of documents in the input folder*/
	public static int docCount =0,kWords=20;
	/*variables to store the number of terms in each index */
	public static int index_1_termCount =0;
	public static int index_2_termCount =0;
	public static int index_3_termCount =0;
	public static int index_4_termCount =0;
	/*variables to store the maximum posting length in each index*/
	public static int maxLengthIndex1 =0;
	public static int maxLengthIndex2 =0;
	public static int maxLengthIndex3 =0;
	public static int maxLengthIndex4 =0;
	/*variables to store the minimum posting length in each index*/
	public static int minLengthIndex1 =0;
	public static int minLengthIndex2 =0;
	public static int minLengthIndex3 =0;
	public static int minLengthIndex4 =0;
	/*variables to store the average posting length in each index*/
	public static int avgLengthIndex1 =0;
	public static int avgLengthIndex2 =0;
	public static int avgLengthIndex3 =0;
	public static int avgLengthIndex4 =0;
	/*hashmaps to store the vocabulary and the posting lists in each index*/
	public static HashMap<String, LinkedHashMap<String,Integer>>invertedIndex1 = new HashMap<String,LinkedHashMap<String,Integer>>();
	public static HashMap<String, LinkedHashMap<String,Integer>>invertedIndex2 = new HashMap<String,LinkedHashMap<String,Integer>>();
	public static HashMap<String, LinkedHashMap<String,Integer>>invertedIndex3 = new HashMap<String,LinkedHashMap<String,Integer>>();
	public static HashMap<String, LinkedHashMap<String,Integer>>invertedIndex4 = new HashMap<String,LinkedHashMap<String,Integer>>();
	/*regular expression to validate url,email and date*/
	public static Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})", Pattern.CASE_INSENSITIVE);
	public static Pattern VALID_URL_REGEX = Pattern.compile("(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]", Pattern.CASE_INSENSITIVE);
	public static Pattern VALID_DATE_REGEX1 = Pattern.compile("^((19|20)\\d\\d)-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])$", Pattern.CASE_INSENSITIVE);
	public static Pattern VALID_DATE_REGEX2 = Pattern.compile("^(([0-9])|([0-2][0-9])|([3][0-1]))\\-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\-\\d{4}$", Pattern.CASE_INSENSITIVE);
	public static Pattern VALID_DATE_REGEX3 = Pattern.compile("(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\\s*(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\s*(([0-9])|([0-2][0-9])|([3][0-1]))\\s*(([0-9])|([0-2][0-9])):(([0-9])|([0-5][0-9])):(([0-9])|([0-5][0-9]))\\sIST\\s((19|20)\\d\\d)$?", Pattern.CASE_INSENSITIVE);
	public static Pattern VALID_DATE_REGEX4 = Pattern.compile("([0-9]{2})/([0-9]{2})/([0-9]{4})");
	public static Pattern VALID_DATE_REGEX5 = Pattern.compile("([0-9]{2})-([0-9]{2})-([0-9]{4})");
	public static Pattern VALID_DATE_REGEX6 = Pattern.compile("([0-9]{4})([0-9]{2})([0-9]{2})");
	public static Pattern VALID_DATE_REGEX7 = Pattern.compile("([0-9]{4})-([0-9]{2})-([0-9]{2})");
	public static Pattern VALID_DATE_REGEX8 = Pattern.compile("([0-9]{4})/([0-9]{2})/([0-9]{2})");
	/*variable to store the k document ids*/
	public static int kDocIdArray[];
	
	/*method to get the document count*/
	public int getDocCount(){
		return docCount;
	}
	
	/*method to get the inverted index 4*/
	public HashMap<String, LinkedHashMap<String,Integer>> getIndex4(){
		return invertedIndex4;
	}
	
	/*method to plot the  graph for  #terms - #tokens*/
	public static void graphPlottingSection4() throws IOException{
		/*creating an object of the Graph class*/
		final GraphSection4 graph4 = new GraphSection4("#Token - #Term ");
		graph4.pack();
	    RefineryUtilities.centerFrameOnScreen(graph4);
	    graph4.setVisible(true);
	}
	
	/*method to plot the graph for collection frequency*/
	public static void graphPlottingSection3() throws IOException{
		/*creating an object of the Graph class*/
		final GraphSection3 graph3 = new GraphSection3("Collection Frequency Plot");
		graph3.pack();
	    RefineryUtilities.centerFrameOnScreen(graph3);
	    graph3.setVisible(true);
	}
	
	/*method to sort the posting lists*/
	public static LinkedHashMap<String,Integer> sortPostingList(LinkedHashMap<String,Integer> postingsList){
		LinkedHashMap<Integer,Integer> tempDocId=new LinkedHashMap<Integer,Integer>();
		/*extracting the integer part from the document id string*/
		for (String key : postingsList.keySet()) {
			int value = Integer.parseInt(key.replaceAll("[^0-9]", ""));
			tempDocId.put(value,postingsList.get(key));
		}
		/*inserting into treemap to sort the posting lists*/
		Map<Integer, Integer> treeMap = new TreeMap<Integer, Integer>(tempDocId);
		LinkedHashMap<String, Integer> sortedPostings = new LinkedHashMap<String, Integer>();
		postingsList=new LinkedHashMap<String,Integer>();
		for (Integer key : treeMap.keySet()) {
			String docId="DOCID:"+key.toString();
			sortedPostings.put(docId, treeMap.get(key));
		}
		return sortedPostings;
	}
	
	/*method to create index 2 by removing stop words*/
	public static void createIndex2() throws FileNotFoundException{
		String line,stopWord;
		/*reading stop words*/
		FileReader fToRead = new FileReader("StopWords.txt");
		Scanner fscan = new Scanner(fToRead);
		/*removing terms with less than 2 characters*/
		for (String key : invertedIndex1.keySet()) {
			if(key.length()>=2){
				invertedIndex2.put(key, invertedIndex1.get(key));
			}
		}
		/*removing stop words from index*/
		while(fscan.hasNextLine()){
			line = fscan.nextLine();
			Scanner sc = new Scanner(line);
			while(sc.hasNext()){
				stopWord = sc.next();
					if(invertedIndex2.containsKey(stopWord.toUpperCase())){
					invertedIndex2.remove(stopWord.toUpperCase());
				}
			}
		}
		/*writing the inverted index 2 into file*/
		PrintWriter writer=new PrintWriter("Inverted_Index_2.txt");
		for (String key : invertedIndex2.keySet()) {
			LinkedHashMap<String,Integer> postingSorted = new LinkedHashMap<String,Integer>();
			postingSorted=sortPostingList(invertedIndex2.get(key));
			invertedIndex2.put(key, postingSorted);
			writer.println(key+":"+postingSorted);
		}
		writer.close();
		fscan.close();
	}
	
	/*method to create inverted index 3 by stemming the terms*/
	public static void createIndex3() throws FileNotFoundException, StemmerException{
		for (String key : invertedIndex2.keySet()) {
			String token=key.trim();
			/*stemming each term in the index*/
			String stemmedWord = EnglishSnowballStemmerFactory.getInstance().process(token.toLowerCase());
			/*removing duplicate stemmed words from the index*/
			if(invertedIndex2.containsKey(stemmedWord.toUpperCase())){
				LinkedHashMap<String,Integer> postings = new LinkedHashMap<String,Integer>();
				LinkedHashMap<String,Integer> postingsToMerge = new LinkedHashMap<String,Integer>();
				postings=invertedIndex2.get(stemmedWord.toUpperCase());
				postingsToMerge=invertedIndex2.get(key);
				/*merging the posting lists of duplicate stemmed terms*/
				for (String iteratorKey : postingsToMerge.keySet()) {
					if(postings.containsKey(iteratorKey)){
						postings.put(iteratorKey, postings.get(iteratorKey)+1);
					}
					else{
						postings.put(iteratorKey,1);
					}
					invertedIndex3.put(stemmedWord.toUpperCase(), postings);
				}
			}
			else{
				/*checking that emails and urls are not stemmed*/
				if(!(key.matches(VALID_EMAIL_ADDRESS_REGEX.toString()) || key.matches(VALID_URL_REGEX.toString()))){
					invertedIndex3.put(stemmedWord.toUpperCase(), invertedIndex2.get(key));
				}
			}
		}
		/*writing the inverted index 3 into a file*/
		PrintWriter writer=new PrintWriter("Inverted_Index_3.txt");
		for (String key : invertedIndex3.keySet()) {
			LinkedHashMap<String,Integer> postingSorted = new LinkedHashMap<String,Integer>();
			postingSorted=sortPostingList(invertedIndex3.get(key));
			invertedIndex3.put(key, postingSorted);
	    	writer.println(key+":"+postingSorted);
	    }  
		writer.close();
	}
	
	/*method to find the average length of postings*/
	public static void 	findAvgLengthPosting(){
		int totalLength=0;
		/*calculating average posting length of inverted index 1*/
		for (String key : invertedIndex1.keySet()) {
			totalLength+=invertedIndex1.get(key).size();
		}
		avgLengthIndex1=totalLength/invertedIndex1.size();
		/*calculating average posting length of inverted index 2*/
		totalLength=0;
		for (String key : invertedIndex2.keySet()) {
			totalLength+=invertedIndex2.get(key).size();
		}
		avgLengthIndex2=totalLength/invertedIndex2.size();
		/*calculating average posting length of inverted index 3*/
		totalLength=0;
		for (String key : invertedIndex3.keySet()) {
			totalLength+=invertedIndex3.get(key).size();
		}
		avgLengthIndex3=totalLength/invertedIndex3.size();
		/*calculating average posting length of inverted index 4*/
		totalLength=0;
		for (String key : invertedIndex4.keySet()) {
			totalLength+=invertedIndex4.get(key).size();
		}
		avgLengthIndex4=totalLength/invertedIndex4.size();
	}
	
	/*method to find the minimum posting length in each index*/
	public static  void findMinLengthPosting(){
		/*calculating minimum posting length of inverted index 1*/
		minLengthIndex1=docCount;
		for (String key : invertedIndex1.keySet()) {
			if(invertedIndex1.get(key).size()<=minLengthIndex1){
				minLengthIndex1=invertedIndex1.get(key).size();
			}
			if(minLengthIndex1==0){
			}
	    }
		/*calculating minimum posting length of inverted index 2*/
		minLengthIndex2=docCount;
		for (String key : invertedIndex2.keySet()) {
			if(invertedIndex2.get(key).size()<=minLengthIndex2){
				minLengthIndex2=invertedIndex2.get(key).size();
			}
	    }  
		/*calculating minimum posting length of inverted index 3*/
		minLengthIndex3=docCount;
		for (String key : invertedIndex3.keySet()) {
			if(invertedIndex3.get(key).size()<=minLengthIndex3){
				minLengthIndex3=invertedIndex3.get(key).size();
			}
	    }  
		/*calculating minimum posting length of inverted index 4*/
		minLengthIndex4=docCount;
		for (String key : invertedIndex4.keySet()) {
			if(invertedIndex4.get(key).size()<=minLengthIndex4){
				minLengthIndex4=invertedIndex4.get(key).size();
			}
	    }  
	}

	/*method to find the maximum posting length in each index*/
	public static  void findMaxLengthPosting(){
		/*calculating maximum posting length of inverted index 1*/
		for (String key : invertedIndex1.keySet()) {
			if(invertedIndex1.get(key).size()>=maxLengthIndex1){
				maxLengthIndex1=invertedIndex1.get(key).size();
			}
	    }  
		/*calculating maximum posting length of inverted index 2*/
		for (String key : invertedIndex2.keySet()) {
			if(invertedIndex2.get(key).size()>=maxLengthIndex2){
				maxLengthIndex2=invertedIndex2.get(key).size();
			}
	    } 
		/*calculating maximum posting length of inverted index 3*/
		for (String key : invertedIndex3.keySet()) {
			if(invertedIndex3.get(key).size()>=maxLengthIndex3){
				maxLengthIndex3=invertedIndex3.get(key).size();
			}
	    }  
		/*calculating maximum posting length of inverted index 4*/
		for (String key : invertedIndex4.keySet()) {
			if(invertedIndex4.get(key).size()>=maxLengthIndex4){
				maxLengthIndex4=invertedIndex4.get(key).size();
			}
	    }  
	}
	
	/*method to write the most frequent k words in an index to a file*/
	public static  void writeMostFrequentWordsToFile(HashMap<String, LinkedHashMap<String,Integer>> invertedIndex,int maxLengthOfIndex,int indexNo) throws IOException{
		FileWriter fw = new FileWriter("Most_Frequent_K_Words.txt", true);
		HashMap<String, LinkedHashMap<String,Integer>>mostFrequentKWords = new HashMap<String,LinkedHashMap<String,Integer>>();
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter writer =new PrintWriter(bw);
		LinkedHashMap<String,Integer> posting = new LinkedHashMap<String,Integer>();
		int i=0, documentGap=0;
		float avgDocumentGap;
		int max=maxLengthOfIndex,k=kWords;
		int[] kDocIdArray=new int[docCount];
		writer.println("Index_"+indexNo+" Details(Words : posting size : average document gap)");
		/*storing the most frequent k words to hashmap*/
		while(k>0){
			for (String key : invertedIndex.keySet()) {
				posting=invertedIndex.get(key);
				if(posting.size()==max)
				{
					mostFrequentKWords.put(key, invertedIndex.get(key));
					k--;
				}	
				if(k==0){
					break;
				}
			}
			max--;
		}
		for (String key : mostFrequentKWords.keySet()) {
			posting=mostFrequentKWords.get(key);
			i=0;
			for (String docId : posting.keySet()){
				String s=docId.substring(6);
				kDocIdArray[i++]=Integer.parseInt(s);
			}
			int numberOfPostings=i;
			documentGap=0;
			/*calculating the average gap in the posting list*/
			for(i=0;i<numberOfPostings-1;i++){
				documentGap=documentGap +(kDocIdArray[i+1]-kDocIdArray[i]);
			}
			avgDocumentGap=(float)documentGap/numberOfPostings;
			/*storing the most frequent k words and average gap into file*/
			writer.println(key+" : "+ posting.size()+" : "+ avgDocumentGap);
		}
		writer.println("___________________________________________________________________");
		writer.close();
	}
	
	/*method to write the median k words in an index to a file*/
	public static  void writeMedianWordsToFile(HashMap<String, LinkedHashMap<String,Integer>> invertedIndex,int avgLengthOfIndex,int indexNo) throws IOException{
		FileWriter fw = new FileWriter("Median_K_Words.txt", true);
		HashMap<String, LinkedHashMap<String,Integer>>medianKWords = new HashMap<String,LinkedHashMap<String,Integer>>();
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter writer =new PrintWriter(bw);
		LinkedHashMap<String,Integer> posting = new LinkedHashMap<String,Integer>();
		int i=0, documentGap=0;
		float avgDocumentGap;
		int avg=avgLengthOfIndex,k=kWords;
		int[] kDocIdArray=new int[docCount];
		writer.println("Index_"+indexNo+" Details(Words : posting size : average document gap)");
		while(k>0){
			/*storing the median k words to hashmap*/
			for (String key : invertedIndex.keySet()) {
				posting=invertedIndex.get(key);
				if(posting.size()==avg)
				{
					medianKWords.put(key, invertedIndex.get(key));
					k--;
				}	
				if(k==0){
					break;
				}
			}
			avg++;
		}
		for (String key : medianKWords.keySet()) {
			posting=medianKWords.get(key);
			i=0;
			for (String docId : posting.keySet()){
				String s=docId.substring(6);
				kDocIdArray[i++]=Integer.parseInt(s);
			}
			int numberOfPostings=i;
			documentGap=0;
			/*calculating the average gap in the posting list*/
			for(i=0;i<numberOfPostings-1;i++){
				documentGap=documentGap +(kDocIdArray[i+1]-kDocIdArray[i]);
			}
			avgDocumentGap=(float)documentGap/numberOfPostings;
			/*storing the median k words and average gap into file*/
			writer.println(key+" : "+ posting.size()+" : "+ avgDocumentGap);
		}
		writer.println("___________________________________________________________________");
		writer.close();
	}
	
	/*method to write the least frequent k words in an index to a file*/
	public static  void writeLeastFreqWordsToFile(HashMap<String, LinkedHashMap<String,Integer>> invertedIndex,int minLengthIndex,int indexNo) throws IOException{
		FileWriter fw = new FileWriter("Least_Frequent_K_Words.txt", true);
		HashMap<String, LinkedHashMap<String,Integer>>leastFrequentKWords = new HashMap<String,LinkedHashMap<String,Integer>>();
		BufferedWriter bw = new BufferedWriter(fw);
		PrintWriter writer =new PrintWriter(bw);
		LinkedHashMap<String,Integer> posting = new LinkedHashMap<String,Integer>();
		int i=0, documentGap=0;
		float avgDocumentGap;
		int min=minLengthIndex,k=kWords;
		int[] kDocIdArray=new int[docCount];
		writer.println("Index_"+indexNo+" Details(Words : posting size : average document gap)");
		while(k>0){
			/*storing the least frequent k words to hashmap*/
			for (String key : invertedIndex.keySet()) {
				posting=invertedIndex.get(key);
				if(posting.size()==min)
				{
					leastFrequentKWords.put(key, invertedIndex.get(key));
					k--;
				}	
				if(k==0){
					break;
				}
			}
			min++;
		}
		for (String key : leastFrequentKWords.keySet()) {
			posting=leastFrequentKWords.get(key);
			i=0;
			for (String docId : posting.keySet()){
				String s=docId.substring(6);
				kDocIdArray[i++]=Integer.parseInt(s);
			}
			int numberOfPostings=i;
			documentGap=0;
			/*calculating the average gap in the posting list*/
			for(i=0;i<numberOfPostings-1;i++){
				documentGap=documentGap +(kDocIdArray[i+1]-kDocIdArray[i]);
			}
			avgDocumentGap=(float)documentGap/numberOfPostings;
			/*storing the least frequent k words and average gap into file*/
			writer.println(key+" : "+ posting.size()+" : "+ avgDocumentGap);
		}
		writer.println("___________________________________________________________________");
		writer.close();
	}
	
	/*method to find the least frequent k words of each index*/
	public static void leastFrequentKWords() throws IOException{
		PrintWriter writer =new PrintWriter("leastFrequentKWords.txt");
		writer.print("");
		writer.close();
		writeLeastFreqWordsToFile(invertedIndex1,minLengthIndex1,1);
		writeLeastFreqWordsToFile(invertedIndex2,minLengthIndex2,2);
		writeLeastFreqWordsToFile(invertedIndex3,minLengthIndex3,3);
		writeLeastFreqWordsToFile(invertedIndex4,minLengthIndex4,4);
	}
	
	/*method to find the most frequent k words of each index*/
	public static void mostFrequentKWords() throws IOException{
		PrintWriter writer =new PrintWriter("mostFrequentKWords.txt");
		writer.print("");
		writer.close();
		writeMostFrequentWordsToFile(invertedIndex1,maxLengthIndex1,1);
		writeMostFrequentWordsToFile(invertedIndex2,maxLengthIndex2,2);
		writeMostFrequentWordsToFile(invertedIndex3,maxLengthIndex3,3);
		writeMostFrequentWordsToFile(invertedIndex4,maxLengthIndex4,4);
		
	}
	
	/*method to find the median k words of each index*/
	public static void medianKWords() throws IOException{
		PrintWriter writer =new PrintWriter("medianKWords.txt");
		writer.print("");
		writer.close();
		writeMedianWordsToFile(invertedIndex1,avgLengthIndex1,1);
		writeMedianWordsToFile(invertedIndex2,avgLengthIndex2,2);
		writeMedianWordsToFile(invertedIndex3,avgLengthIndex3,3);
		writeMedianWordsToFile(invertedIndex4,avgLengthIndex4,4);
		
	}
	
	/*method to find the number of terms in each index*/
	public static void findTermCount(){
		index_1_termCount=invertedIndex1.size();
		index_2_termCount=invertedIndex2.size();
		index_3_termCount=invertedIndex3.size();
		index_4_termCount=invertedIndex4.size();
	}
	
	/*method to create inverted index 4 by removing the terms which occurs in less than 2% of the documents*/
	public static void createIndex4() throws FileNotFoundException{
		File folder = new File("Input");
		double threshold=0;
		File[] listOfFiles = folder.listFiles();
		/*counting the number of documents*/
		for (File dictionaryFile : listOfFiles) {
		    if (dictionaryFile.isFile()) {
		    	docCount+=1;
		    }
		}
		/*removing terms which occurs in less than 2% of the documents*/
		threshold=(2*docCount)/100.00;
		for (String key : invertedIndex3.keySet()) {
			if(invertedIndex3.get(key).size()>=threshold){
				invertedIndex4.put(key, invertedIndex3.get(key));
			}
	    }  
		/*writing the inverted index 4 into a file*/
		PrintWriter writer=new PrintWriter("Inverted_Index_4.txt");
		for (String key : invertedIndex4.keySet()) {
			LinkedHashMap<String,Integer> postingSorted = new LinkedHashMap<String,Integer>();
			postingSorted=sortPostingList(invertedIndex4.get(key));
			invertedIndex4.put(key, postingSorted);
	    	writer.println(key+":"+invertedIndex4.get(key));
	    	//System.out.println(key+":"+invertedIndex4.get(key));
	    } 
		writer.close();
	}
	
	/*method to create the inverted index 1*/
	public static void createIndex1(String docId,String match){
		LinkedHashMap<String,Integer> postings =new LinkedHashMap<String,Integer>();
		LinkedHashMap<String,Integer> postingsSorted =new LinkedHashMap<String,Integer>();
		/*checking if the index contains the term already*/
		if(invertedIndex1.containsKey(match)){
			postings=invertedIndex1.get(match);
			/*checking if the document id is present in the posting list of the term*/
			if(postings.containsKey(docId)){
				postings.put(docId, (postings.get(docId))+1);
				postingsSorted=sortPostingList(postings);
				invertedIndex1.put(match, postingsSorted);
			}
			else{
				postings.put(docId, 1);
				invertedIndex1.put(match, postings);
			}
		}
		else{
			postings.put(docId, 1);
			invertedIndex1.put(match,postings);
		}
	}
	
	/*main method to call all other method*/
	public static void main(String[] args) throws Exception {
		String vocArray[];
		File folder = new File("Input");
		File[] listOfFiles = folder.listFiles();
		PrintWriter tempWriter;
		String vocabulary,docId=null;
		Matcher matcher;
		File tempFile=new File("TempFile");;
		String line=null;
		System.out.println("Creating Index 1....");
		for (File dictionaryFile : listOfFiles) {
		    if (dictionaryFile.isFile()) {
		    	/*storing each document to a temporary file for processing*/
		    	tempFile=new File("TempFile");
		    	tempWriter=new PrintWriter(tempFile);
		    	/*scanning each line of the document*/
		    	Scanner inputFile = new Scanner(dictionaryFile);
		    	if(inputFile.hasNext()){
		    		line=inputFile.nextLine();
		    	}
		    	/*removing the metadata in the document*/
				while(true){
					if(line.startsWith("DOCID:")){
						docId=line;
						line=line.replaceAll("DOCID:", " ");
						tempWriter.write(line);
					}
					else if(line.startsWith("URL:")){
						line=line.replaceAll("URL:", " ");
						tempWriter.write(line);
					}
					else if(line.startsWith("METADATA:")){
						line=line.replaceAll("METADATA:", " ");
						tempWriter.write(line);
					}
					else if(line.startsWith("DATE:")){
						line=line.replaceAll("DATE:", " ");
						tempWriter.write(line);
					}
					else if(line.startsWith("TITLE:")){
						line=line.replaceAll("TITLE:", " ");
						tempWriter.write(line);
					}
					else if(line.startsWith("CONTENT:")){
						line=line.replaceAll("CONTENT:", " ");
						tempWriter.write(line);
					}
					if(inputFile.hasNext()){
						line=inputFile.nextLine();
					}
					else{
						break;
					}
				}
				tempWriter.close();
				inputFile = new Scanner(tempFile);
				if(inputFile.hasNext()){
					line=inputFile.nextLine();
				}
				while(true){
						/*adding the dates in the file into the index and removing it from the temporary file*/
						matcher = VALID_DATE_REGEX1.matcher(line);
						while(matcher.find()) {		
							createIndex1(docId,matcher.group());
							line=line.replaceAll(VALID_DATE_REGEX1.toString(), " ");
						}
						matcher = VALID_DATE_REGEX2.matcher(line);
						while(matcher.find()) {		
							createIndex1(docId,matcher.group());
							line=line.replaceAll(VALID_DATE_REGEX2.toString(), " ");
						}
						matcher = VALID_DATE_REGEX3.matcher(line);
						while(matcher.find()) {		
							createIndex1(docId,matcher.group());
							line=line.replaceAll(VALID_DATE_REGEX3.toString(), " ");
						}
						matcher = VALID_DATE_REGEX4.matcher(line);
						while(matcher.find()) {		
							createIndex1(docId,matcher.group());
							line=line.replaceAll(VALID_DATE_REGEX4.toString(), " ");
						}
						matcher = VALID_DATE_REGEX5.matcher(line);
						while(matcher.find()) {		
							createIndex1(docId,matcher.group());
							line=line.replaceAll(VALID_DATE_REGEX5.toString(), " ");
						}
						matcher = VALID_DATE_REGEX6.matcher(line);
						while(matcher.find()) {		
							createIndex1(docId,matcher.group());
							line=line.replaceAll(VALID_DATE_REGEX6.toString(), " ");
						}
						matcher = VALID_DATE_REGEX7.matcher(line);
						while(matcher.find()) {		
							createIndex1(docId,matcher.group());
							line=line.replaceAll(VALID_DATE_REGEX3.toString(), " ");
						}
						matcher = VALID_DATE_REGEX8.matcher(line);
						while(matcher.find()) {		
							createIndex1(docId,matcher.group());
							line=line.replaceAll(VALID_DATE_REGEX8.toString(), " ");
						}
						/*adding the email ids in the file into the index and removing it from the temporary file*/
						matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(line);
						while(matcher.find()) {		
							createIndex1(docId,matcher.group());
							line=line.replaceAll(VALID_EMAIL_ADDRESS_REGEX.toString(), " ");
						}
						/*adding the urls in the file into the index and removing it from the temporary file*/
						matcher = VALID_URL_REGEX.matcher(line);
						while(matcher.find()) {		
							createIndex1(docId,matcher.group());
							line=line.replaceAll(VALID_URL_REGEX.toString(), " ");
						}
						if(inputFile.hasNext()){
							line=inputFile.nextLine();
						}
						else{
							break;
						}
				}
				tempFile=new File("TempFile");
				tempWriter=new PrintWriter(tempFile);
				tempWriter.write("");
				tempWriter.write(line);
				tempWriter.close();
				inputFile.close();
				/*processing the rest of the tokens in the temporary file*/
				inputFile = new Scanner(tempFile);
				while( inputFile.hasNext()) {
					vocabulary=inputFile.next().toUpperCase() ;
					/*splitting the lines into tokens*/
					vocArray=vocabulary.split("[^\\w']+");
					for(int i=0;i<vocArray.length;i++){
						LinkedHashMap<String,Integer> posting = new LinkedHashMap<String,Integer>();
						LinkedHashMap<String,Integer> postingSorted = new LinkedHashMap<String,Integer>();
						posting.put(docId,1);
						/*checking if the token is alphanumeric*/
						if(Pattern.matches("^[a-zA-Z0-9]*[a-zA-Z][a-zA-Z0-9]*$", vocArray[i])){
							/*checking if the index already contains the token*/
							if(invertedIndex1.containsKey(vocArray[i])){
								posting=invertedIndex1.get(vocArray[i]);
								/*checking if the document id is already present in the posting list*/
								if(posting.containsKey(docId)){
									/*increasing the term frequency*/
									posting.put(docId, posting.get(docId)+1);
								}
								/*adding new document id to postings list*/
								else{
									posting.put(docId,1);
									postingSorted=sortPostingList(posting);
									invertedIndex1.put(vocArray[i], postingSorted);
								}
							}
							/*adding new term to the index*/
							else{
								invertedIndex1.put(vocArray[i],posting);
							}
						}
					}
		        }
		
				inputFile.close();
		    }
		}
		PrintWriter writer=new PrintWriter("Inverted_Index_1.txt");
		/*writing the inverted index into file*/
		for (String key : invertedIndex1.keySet()) {
	    	writer.println(key+":"+invertedIndex1.get(key));
	    } 
		writer.close();
		System.out.println("Creating Index 2....");
		/*invoking method to create inverted index 2*/
		createIndex2();
		System.out.println("Creating Index 3....");
		/*invoking method to create inverted index 3*/
		createIndex3();
		System.out.println("Creating Index 4....");
		/*invoking method to create inverted index 4*/
		createIndex4();
		PrintWriter pw=new PrintWriter("Count&LengthOfPostings.txt");
		System.out.println("Finding number of terms in each index....");
		/*invoking method to find the number of terms in each inverted index*/
		findTermCount();
		/*storing the number of documents into file*/
		pw.println("Document count : "+docCount+"\n");
		/*storing the term count of each inverted index into file*/
		pw.println("Number of terms in Index 1 : "+index_1_termCount);
		pw.println("Number of terms in Index 2 : "+index_2_termCount);
		pw.println("Number of terms in Index 3 : "+index_3_termCount);
		pw.println("Number of terms in Index 4 : "+index_4_termCount+"\n");
		System.out.println("Finding maximum length of posting list....");
		/*invoking method to find the maximum posting length in each inverted index*/
		findMaxLengthPosting();
		/*storing the maximum posting length of each inverted index into file*/
		pw.println("Maximum posting length in Index 1 : "+maxLengthIndex1);
		pw.println("Maximum posting length in Index 2 : "+maxLengthIndex2);
		pw.println("Maximum posting length in Index 3 : "+maxLengthIndex3);
		pw.println("Maximum posting length in Index 4 : "+maxLengthIndex4+"\n");
		System.out.println("Finding minimum length of posting list....");
		/*invoking method to find the minimum posting length in each inverted index*/
		findMinLengthPosting();
		/*storing the minimum posting length of each inverted index into file*/
		pw.println("Minimum posting length in Index 1 : "+minLengthIndex1);
		pw.println("Minimum posting length in Index 2 : "+minLengthIndex2);
		pw.println("Minimum posting length in Index 3 : "+minLengthIndex3);
		pw.println("Minimum posting length in Index 4 : "+minLengthIndex4+"\n");
		System.out.println("Finding average length of posting list....");
		/*invoking method to find the average posting length in each inverted index*/
		findAvgLengthPosting();
		/*storing the average posting length of each inverted index into file*/
		pw.println("Average posting length in Index 1 : "+avgLengthIndex1);
		pw.println("Average posting length in Index 2 : "+avgLengthIndex2);
		pw.println("Average posting length in Index 3 : "+avgLengthIndex3);
		pw.println("Average posting length in Index 4 : "+avgLengthIndex4);
		pw.close();
		System.out.println("Finding most frequent words....");
		/*invoking method to find the most frequent k words in each inverted index*/
		mostFrequentKWords();
		System.out.println("Finding median words....");
		/*invoking method to find the median k words in each inverted index*/
		medianKWords();
		System.out.println("Finding least frequent words....");
		/*invoking method to find the least frequent k words in each inverted index*/
		leastFrequentKWords();
		System.out.println("Plotting graph for collection frequency....");
		/*invoking method to plot a graph for collection frequency vs rank*/
		graphPlottingSection3();
		System.out.println("Plotting #term - #token graph....");
		/*invoking method to plot a graph for #terms vs #tokens*/
		graphPlottingSection4();
		System.out.println("Completed....!");
		
	}
	
	
}