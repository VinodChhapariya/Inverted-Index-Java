package index;
import java.awt.BorderLayout;
import java.awt.Container;
import java.io.File;
import java.io.IOException;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
 import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
 import org.jfree.chart.plot.PlotOrientation;
 import org.jfree.data.xy.XYSeries;
 import org.jfree.data.xy.XYSeriesCollection;
 import org.jfree.ui.ApplicationFrame;
public class GraphSection3 extends ApplicationFrame {
	public static Map<String,Integer> collectionFrequency =new HashMap<String,Integer>(); 
	public static Map<String,Integer> top1000 =new LinkedHashMap<String,Integer>(); 
	public static HashMap<String, LinkedHashMap<String,Integer>>invertedIndex4 = new HashMap<String,LinkedHashMap<String,Integer>>();
	/*method to find the collection frequency of each term*/
	public static void findCollectionFrequency(){
		int collectionFrequencyofTerm=0;
		for (String key : invertedIndex4.keySet()) {
			LinkedHashMap<String,Integer>postingList=new LinkedHashMap<String,Integer>();
			postingList=invertedIndex4.get(key);
			collectionFrequencyofTerm=0;
			for (String docId : postingList.keySet()) {
				collectionFrequencyofTerm+=postingList.get(docId);
			}
			collectionFrequency.put(key, collectionFrequencyofTerm);
		}
		collectionFrequency.entrySet().stream().sorted(Map.Entry.<String, Integer>comparingByValue().reversed()).limit(1000).forEachOrdered(x -> top1000.put(x.getKey(), x.getValue()));
	}
	public GraphSection3(String title) throws IOException,ConcurrentModificationException,NullPointerException {
		super(title);
		IndexMain index=new IndexMain();
		invertedIndex4=index.getIndex4();
		/*invoking method to find the collection frequency*/
		findCollectionFrequency();
		final XYSeries series = new XYSeries("Data");
		int i=1;
		/*adding log(rank) and log(collection frequency) as x,y respectively to plot the graph*/
		for (String key : top1000.keySet()){
			series.add(Math.log10(i),Math.log10(top1000.get(key)));
			i++;
		}
		/*plotting the graph*/
	    final XYSeriesCollection data = new XYSeriesCollection(series);
	    final JFreeChart chart = ChartFactory.createXYLineChart("Rank Vs Collection Frequency","log(rank)","log(collection frequency)",data,PlotOrientation.VERTICAL,true,true,false);
	    ChartUtilities.saveChartAsJPEG(new File("rank_collectionFrequency_graph.jpg"), chart, 900, 500);
	    final ChartPanel chartPanel = new ChartPanel(chart);
	    chartPanel.setPreferredSize(new java.awt.Dimension(900, 500));
	    JFrame frame = new JFrame("log(rank) - log(collection frequency plot");
	    Container pane = frame.getContentPane();
	    pane.setLayout(new BorderLayout()); 
	    pane.add(chartPanel);
	    frame.pack();
	    frame.setLocation(1,400);
	    frame.setVisible(true);
	    
	}

}
